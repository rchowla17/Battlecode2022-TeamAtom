package atomV4d4d1;

import battlecode.common.*;
import java.util.*;

public class Watchtower {

}
