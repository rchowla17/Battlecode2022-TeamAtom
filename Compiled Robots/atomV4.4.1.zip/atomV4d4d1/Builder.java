package atomV4d4d1;

import battlecode.common.*;
import java.util.*;

public class Builder {
    static void runBuilder(RobotController rc) throws GameActionException {

    }

    static void init(RobotController rc) throws GameActionException {

    }
}
