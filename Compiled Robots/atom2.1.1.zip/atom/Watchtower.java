package atom;

import battlecode.common.*;
import java.util.*;

public class Watchtower {

}
