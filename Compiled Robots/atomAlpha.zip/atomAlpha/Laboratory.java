package atomAlpha;

import battlecode.common.*;
import java.util.*;

public class Laboratory {

}